# Report build and quality assurance

## Primary report

Source: `revised_full_mathematical_peer_review.md`.

```bash
pandoc revised_full_mathematical_peer_review.md \
  --standalone \
  --from markdown+raw_tex+tex_math_dollars \
  --to latex \
  --output revised_full_mathematical_peer_review.tex
pdflatex -interaction=nonstopmode -halt-on-error revised_full_mathematical_peer_review.tex
pdflatex -interaction=nonstopmode -halt-on-error revised_full_mathematical_peer_review.tex
pdflatex -interaction=nonstopmode -halt-on-error revised_full_mathematical_peer_review.tex
```

Final length: 25 letter-size pages.

## Corrective addendum

Source: `corrective_addendum_and_results_map.md`; built by the same pipeline. Final length: 4 letter-size pages.

## QA disposition

The final LaTeX transcripts contain no fatal errors, LaTeX warnings, package warnings, overfull boxes, underfull boxes, missing characters, or undefined control sequences. Both PDFs were rendered at 200 dpi and inspected page by page and as contact sheets. `pdf_preflight.py` reports that each file is openable, unencrypted, text-based, and non-XFA. No clipping, overlap, black squares, or broken glyphs was observed.
